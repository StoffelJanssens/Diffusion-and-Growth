import numpy as np
import matplotlib.pyplot as plt


def y_array_call(data_type, n_s):
    # y_array = np.array([np.mean(np.load('n_s_' + n_s + '/n_s_' + n_s + '_SD_0_time.npy')[:, data_type]),
    #                     np.mean(np.load('n_s_' + n_s + '/n_s_' + n_s + '_SD_005_time.npy')[:, data_type]),
    #                     np.mean(np.load('n_s_' + n_s + '/n_s_' + n_s + '_SD_010_time.npy')[:, data_type]),
    #                     np.mean(np.load('n_s_' + n_s + '/n_s_' + n_s + '_SD_015_time.npy')[:, data_type]),
    #                     np.mean(np.load('n_s_' + n_s + '/n_s_' + n_s + '_SD_020_time.npy')[:, data_type]),
    #                     np.mean(np.load('n_s_' + n_s + '/n_s_' + n_s + '_SD_025_time.npy')[:, data_type])])

    y_array = np.array([np.mean(np.load('n_s_' + n_s + '/n_s_' + n_s + '_SD_005_time.npy')[:, data_type]),
                        np.mean(np.load('n_s_' + n_s + '/n_s_' + n_s + '_SD_010_time.npy')[:, data_type]),
                        np.mean(np.load('n_s_' + n_s + '/n_s_' + n_s + '_SD_015_time.npy')[:, data_type]),
                        np.mean(np.load('n_s_' + n_s + '/n_s_' + n_s + '_SD_020_time.npy')[:, data_type]),
                        np.mean(np.load('n_s_' + n_s + '/n_s_' + n_s + '_SD_025_time.npy')[:, data_type])])

    return y_array


# std_array = [0, 0.05, 0.10, 0.15, 0.20, 0.25]
std_array = [0.05, 0.10, 0.15, 0.20, 0.25]

# symb_array = ['o-', 'v-', '^-', '<-', '>-', '8-']
symb_array = ['o-', 'v-', '^-', '<-', '>-']

ns_array = ['25', '50', '100', '150', '200']

# data type: 0 = diffusion length, 1 = scaled concentration, 2 = computing time

# plotting computation time
for ns, symb in zip(ns_array, symb_array):
    plt.plot(std_array, y_array_call(2, ns), symb, label=ns)

# ax = plt.gca()
# ax.set_ylim([0.0009, 0.1])
# plt.yscale('log')
# plt.xscale('log')

plt.xlabel("standard deviation noise [ul]")
plt.ylabel("mean CPU time")

plt.legend()
plt.show()
