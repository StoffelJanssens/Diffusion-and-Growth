import numpy as np
import matplotlib.pyplot as plt


def y_array_call(data_type, n_s):
    # y_array = np.array([np.mean(np.load('n_s_' + n_s + '/n_s_' + n_s + '_SD_0_time.npy')[:, data_type]),
    #                     np.mean(np.load('n_s_' + n_s + '/n_s_' + n_s + '_SD_005_time.npy')[:, data_type]),
    #                     np.mean(np.load('n_s_' + n_s + '/n_s_' + n_s + '_SD_010_time.npy')[:, data_type]),
    #                     np.mean(np.load('n_s_' + n_s + '/n_s_' + n_s + '_SD_015_time.npy')[:, data_type]),
    #                     np.mean(np.load('n_s_' + n_s + '/n_s_' + n_s + '_SD_020_time.npy')[:, data_type]),
    #                     np.mean(np.load('n_s_' + n_s + '/n_s_' + n_s + '_SD_025_time.npy')[:, data_type])])

    y_array_mean = np.array([np.mean(np.load('n_s_' + n_s + '/n_s_' + n_s + '_SD_005_time.npy')[:, data_type]),
                             np.mean(np.load('n_s_' + n_s + '/n_s_' + n_s + '_SD_010_time.npy')[:, data_type]),
                             np.mean(np.load('n_s_' + n_s + '/n_s_' + n_s + '_SD_015_time.npy')[:, data_type]),
                             np.mean(np.load('n_s_' + n_s + '/n_s_' + n_s + '_SD_020_time.npy')[:, data_type]),
                             np.mean(np.load('n_s_' + n_s + '/n_s_' + n_s + '_SD_025_time.npy')[:, data_type])])

    y_array_std = np.array([np.std(np.load('n_s_' + n_s + '/n_s_' + n_s + '_SD_005_time.npy')[:, data_type]),
                            np.std(np.load('n_s_' + n_s + '/n_s_' + n_s + '_SD_010_time.npy')[:, data_type]),
                            np.std(np.load('n_s_' + n_s + '/n_s_' + n_s + '_SD_015_time.npy')[:, data_type]),
                            np.std(np.load('n_s_' + n_s + '/n_s_' + n_s + '_SD_020_time.npy')[:, data_type]),
                            np.std(np.load('n_s_' + n_s + '/n_s_' + n_s + '_SD_025_time.npy')[:, data_type])])

    return y_array_mean, y_array_std


# std_array = [0, 0.05, 0.10, 0.15, 0.20, 0.25]
std_array = [0.05, 0.10, 0.15, 0.20, 0.25]

# symb_array = ['o-', 'v-', '^-', '<-', '>-', '8-']
symb_array = ['o-', 'v-', '^-', '<-', '>-']

ns = '100'

# data type: 0 = diffusion length, 1 = scaled concentration, 2 = computing time

# plotting relative errors on diffusion lengths

mean_d_a_array, std_d_a_array = y_array_call(0, ns)
mean_sigma_array, std_sigma_array = y_array_call(1, ns)

fig, ax1 = plt.subplots()
ax1.errorbar(std_array, mean_d_a_array, yerr=std_d_a_array, marker='o', capsize=5)

# fig, ax1 = plt.subplots()
# ax1.errorbar(std_array, mean_sigma_array, yerr=std_sigma_array, marker='o', capsize=5)

# ax2 = ax1.twinx()
# ax2.plot(std_array, mean_sigma_array, 'v-', label='sigma')


# ax = plt.gca()
# ax.set_ylim([0.01, 1])
# plt.yscale('log')
# plt.xscale('log')

plt.xlabel("stand dev noise")
plt.ylabel("mean d_a values")


plt.savefig('plot_d_a_std.pdf')
plt.show()
