import numpy as np
import matplotlib.pyplot as plt
from scipy.optimize import curve_fit


def poly(x, a, b):
    return a * x ** b


# Data
x_data = np.array([25, 50, 100, 200, 400, 800, 1600])  # 1600 add
y_data = np.zeros(7, dtype='float')

for index, x_val in enumerate(x_data):
    y_data[index] = np.load('data_time_' + str(x_val) + '.npy')

params_poly, _ = curve_fit(poly, x_data, y_data)

# Predict y values
y_poly = poly(x_data, *params_poly)

# Plot data and fitted models
plt.plot(x_data, y_data, 'o', label="Data")
plt.plot(x_data, y_poly, '-', label="Power Law Fit (n^b)")

# Log plot
plt.yscale('log')
plt.xscale('log')
plt.xlabel("number of chain nodes")
plt.ylabel("time [s]")
plt.savefig('plot_time.pdf')
plt.show()

# Returning the polynomial exponent for the best fit
print(params_poly)
