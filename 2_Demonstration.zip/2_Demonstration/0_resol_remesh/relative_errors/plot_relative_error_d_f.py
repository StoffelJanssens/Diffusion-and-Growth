import numpy as np
import matplotlib.pyplot as plt

# Reference profile obtained with 1600 nodes
# n_f denotes the number of nodes taken for remeshing
n_r_array = np.array([25, 50, 100, 200, 400, 800, 1600])
n_g_0_array = np.array([25, 50, 100, 200, 400, 800, 1600])
symb_array = ['o-', 'v-', '^-', '<-', '>-', '8-', 's-']

for n_g_0, symb in zip(n_r_array, symb_array):
    plt.plot(n_r_array, np.load('data_resol_remesh_' + str(n_g_0) + '.npy')[:, 0], symb, label=n_g_0)


plt.yscale('log')
plt.xscale('log')
plt.xlabel("$n_r$")
plt.ylabel("relative error d_f")
plt.legend()
plt.savefig('plot_relative_error_d_f.pdf')
plt.show()
